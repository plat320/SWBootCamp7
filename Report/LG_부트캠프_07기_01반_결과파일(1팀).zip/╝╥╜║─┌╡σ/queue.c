#include "device_driver.h"
#include "queue.h"
#include <string.h>

// static ������ ���� ����
char queue_buffer[QUEUE_BUFFER_SIZE] __attribute__((__aligned__(8)));

// ���� ���� �Լ�
char* _OS_Get_Buffer(int size) {
	static char* buffer_limit = queue_buffer;
	static char* pbuffer = queue_buffer + QUEUE_BUFFER_SIZE;

    size = (size + 7) & ~0x7; // 8����Ʈ ����

    if (pbuffer - size < buffer_limit) {
        return (char*)0; // �޸� ����
    }
    pbuffer -= size;

    return pbuffer;
}

// Queue ���� �Լ�
int createQueue(Queue* q, int data_size, int number_of_elements, int no_task) {
    q->front = NULL;
    q->rear = NULL;
    q->size = 0;
    q->data_size = data_size;
    q->no_task = no_task;
    q->max_size = number_of_elements;

    // �̸� �Ҵ�� �޸𸮷� ��� �ʱ�ȭ
    q->free_nodes = (Node*)_OS_Get_Buffer(sizeof(Node));
    if (q->free_nodes == NULL) {
        return QUEUE_FAIL_ALLOCATE;
    }
    if(number_of_elements == -1) {
    	number_of_elements = MAX_QUEUE_SIZE;
    }

    Node* current_node = q->free_nodes;
    int i;
    for (i = 0; i < number_of_elements - 1; ++i) {
        current_node->data = _OS_Get_Buffer(data_size);
        if (current_node->data == NULL) {
            return QUEUE_FAIL_ALLOCATE;
        }
        current_node->next = (Node*)_OS_Get_Buffer(sizeof(Node));
        if (current_node->next == NULL) {
            return QUEUE_FAIL_ALLOCATE;
        }
        current_node = current_node->next;
    }
    current_node->data = _OS_Get_Buffer(data_size);
    if (current_node->data == NULL) {
        return QUEUE_FAIL_ALLOCATE;
    }
    current_node->next = NULL;
    return QUEUE_SUCCESS;
}

// Queue�� ������ �߰� �Լ�
int enqueue(Queue* q, const void* data) {
    if (isFull(q)) {
        return -1;
    }

    Node* new_node = q->free_nodes;
    q->free_nodes = q->free_nodes->next;

    memcpy(new_node->data, data, q->data_size);
    new_node->next = NULL;

    if (q->rear != NULL) {
        q->rear->next = new_node;
    }
    q->rear = new_node;

    if (q->front == NULL) {
        q->front = new_node;
    }

    q->size++;
    return 0;
}

// Queue���� ������ ���� �Լ�
// no_task�� HAVE_PERMISSION(-1)�̸� task_no Ȯ�� ��Ȱ��ȭ
int dequeue(Queue* q, void* data, int no_task) {
    if (isEmpty(q)) {
        return DEQUEUE_EMPTY;
    }
    if (no_task != HAVE_PERMISSION && q->no_task != no_task) {
    	return DEQUEUE_NO_PERMISSION;
    }

//    Uart_Printf("--- 1 ---\n");
    Node* temp = q->front;
//    Uart_Printf("--- 2 ---\n");
//    Uart_Printf("q->front: %x\n", q->front);
//    Uart_Printf("((POINT*)q->front)->x: %d\n", ((POINT*)(q->front->data))->x);
//    Uart_Printf("q->size: %d\n", q->size);
//    Uart_Printf("data: %x\n", data);
//    Uart_Printf("temp->data: %x\n", temp->data);
//    Uart_Printf("q->data_size: %d\n", q->data_size);
    memcpy(data, temp->data, q->data_size);
//    Uart_Printf("--- 3 ---\n");
    q->front = q->front->next;
//    Uart_Printf("--- 4 ---\n");

    if (q->front == NULL) {
        q->rear = NULL;
    }

    temp->next = q->free_nodes;
    q->free_nodes = temp;

    q->size--;
    return DEQUEUE_SUCCESS;
}

// Queue�� ��� �ִ��� Ȯ���ϴ� �Լ�
int isEmpty(Queue* q) {
    return (q->size == 0);
}

// Queue�� �� �� �ִ��� Ȯ���ϴ� �Լ�
int isFull(Queue* q) {
    return (q->size == q->max_size);
}
